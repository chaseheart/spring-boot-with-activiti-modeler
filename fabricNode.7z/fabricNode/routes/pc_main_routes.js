/**
 * 
 */
var express = require('express');
var router = express.Router();
var session = require('express-session')
/* GET home page. */
router.get('/', function(req, res, next) {
	res.render('pc_main');
});

//用户登出
router.get('/logout', function(req, res) {
	req.session.destroy(function(){
		res.redirect('/');
	})
});

module.exports = router;