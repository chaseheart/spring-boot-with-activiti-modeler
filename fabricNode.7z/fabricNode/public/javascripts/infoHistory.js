/**
 * 
 */
$(function() {
	if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|OperaMini/i
			.test(navigator.userAgent)) {
		$("#nav").remove();
	} else {
		$(".breadcrumb").remove();
	}
	getHistoryData();
})

function getHistoryData() {
	var postUrl = "";
	$.ajax({
		type : 'get',
		url : postUrl,
		dataType : 'json',
		success : function(data) {
			if (data.result == 1) {
				var data1 = JSON.parse(Decrypt(JSON.parse(data.details[0]).data));
				var data2 = JSON.parse(Decrypt(JSON.parse(data.details[1]).data));
				var compareResult = compareData(data1,data2);
				sendHistory(compareResult);
			}
		}
	})
}

function compareData(data1, data2) {
	// check language
	var lang = sessionStorage.getItem("lang")
	var string_add = " ";
	var string_to = " ";
	var string_change = " ";
	var string_from = " ";
	var string_nothing = " ";

	if (lang != 'zh_CN') {
		string_add = " add ";
		string_to = " to ";
		string_change = " change ";
		string_from = " from ";
	} else {
		string_add = " 添加 ";
		string_to = " 为 ";
		string_change = " 修改 ";
		string_from = " 从 ";
	}

	var compareResult={};
	for ( var key in data2) {
		var msgDetails = ""
		if (key == "theDate" || key == "role"
				|| key == "userName"|| key == "userId") {
			continue;
		}
		if (data1[key] == undefined || data1[key] =="") {
			msgDetails =  data2.userName
					+ string_add + key + string_to
					+ data2[key];
		} else if (data1[key] != data2[key]) {
			msgDetails =  data2.userName
					+ string_change + key + string_from
					+ data1[key] + string_to
					+ data2[key];
		}
		compareResult.push({key:msgDetails});
	}
	return compareResult;
}

// show history on page
function sendHistory(data) {
//	var data = {
//		factory_brand : "a 2 b",
//		factory_modelName : "a 2 c",
//		factory_modelCode : "a 2 bh",
//		factory_movement : "a 2 bg",
//		factory_jewls : "a 2 bhj",
//		factory_material : "a 2 bghj",
//		factory_treatement : "a 2 bghj",
//		factory_bezel : "a 2 bghj",
//		factory_index : "a 2 brty",
//
//		trading_distributorName : "aasd 2 dfd",
//		trading_distributorInfor : "a 2 34",
//	};

	console.log(data);
	if (JSON.stringify(data) == "{}") {
		var appSen = '<div class="form-group"><label for="" class="col-sm-4 control-label lang-change">未作出任何改变</label></div>';
		$("#factory-data").children("form").append(appSen);
	} else {
		for ( var key in data) {
			var appSen = '<div class="form-group">';
			appSen += '<label for="" id="' + "form-html-string_" + key
					+ '" class="col-sm-4 control-label lang-change">' + key
					+ '</label>';
			appSen += '<div class="col-sm-6"><span>' + data[key]
					+ '</span></div>';
			appSen += '</div>';
			$("#factory-data").children("form").append(appSen);

			continue;
		}
		var lang = sessionStorage.getItem("lang")
		if (lang != 'zh_CN') {
			lang = 'en_US'
		}
		loadProperties(lang);
	}
}