/**
 * 
 */
// test data
// var data = {
// abcd : '123456',
// factory_RRP : "25",
// factory_accessories : "26啊啊",
// factory_bezel : "10",
// factory_brand : "2",
// factory_claspMaterial : "23",
// factory_claspType : "22",
// factory_dial : "11",
// factory_dimension : "15",
// factory_functions : [ "calendar", "tourbillon" ],
// factory_gem : true,
// factory_gender : "woman",
// factory_glass : "9",
// factory_greatFunction : "n",
// factory_index : "12",
// factory_jewls : "6",
// factory_material : "7",
// factory_modelCode : "4",
// factory_modelName : "3",
// factory_movement : "5",
// factory_produce : "19",
// factory_productionNo : "27",
// factory_strap : "nylon",
// factory_strapSize : "17",
// factory_transparent : false,
// factory_treatement : "8",
// factory_water : true
// };
$(function() {

	//doSearch()
	$("#pcInfoUpdateFactory-html-update").bind('click', function() {

		doFactoryEntry();
	})

	// test showItemData
	// showItemData(data)

})
// get item data from fabric
function doSearch() {
	var postUrl = "/dataSearch/searchOne";
	$.ajax({
		type : 'get',
		url : postUrl,
		dataType : 'json',
		success : function(data) {
			if (data.result == 1) {
				$('#itemId').val(data.details.id);
				$('#itemId').attr("disabled", true);
				$('#data-version').html(data.details.version);
				$('#data-code').html(data.details.data)
				itemData = JSON.parse(Decrypt(data.details.data));
				showData(itemData);
			} else {
				alert("no data");
			}
		}
	})
}
// show item into page
function showItemData(itemData) {
	$('#brand').val(itemData.factory_brand);
	$('#modelName').val(itemData.factory_modelName);
	$('#modelCode').val(itemData.factory_modelCode);
	$('#movement').val(itemData.factory_movement);
	$('#jewls').val(itemData.factory_jewls);
	$('#material').val(itemData.factory_material);
	$('#treatement').val(itemData.factory_treatement);
	$('#glass').val(itemData.factory_glass);
	$('#bezel').val(itemData.factory_bezel);
	$('#dial').val(itemData.factory_dial);
	$('#index').val(itemData.factory_index);

	for ( var f in itemData.factory_functions) {
		$(
				"#functions-checkbox input[value="
						+ itemData.factory_functions[f] + "]").prop("checked",
				true);
	}
	if (itemData.factory_greatFunction == 'y') {
		$("input[name='great-function'][value='y']").prop("checked", true);
	} else {
		$("input[name='great-function'][value='n']").prop("checked", true);
	}
	$('#dimension').val(itemData.factory_dimension);
	$('#strap option[value=' + itemData.factory_strap + ']').attr('selected',
			true);
	$('#strapSize').val(itemData.factory_strapSize);
	if (itemData.factory_gem == 'true' || itemData.factory_gem == true) {
		$('#gem').prop("checked", true);
	}
	$('#produce').val(itemData.factory_produce);
	if (itemData.factory_gender == 'man') {
		$("input[name='gender'][value='man']").prop("checked", true);
	} else {
		$("input[name='gender'][value='woman']").prop("checked", true);
	}
	if (itemData.factory_water == 'true' || itemData.factory_water == true) {
		$('#water').prop("checked", true);
	}
	$('#claspType').val(itemData.factory_claspType);
	$('#claspMaterial').val(itemData.factory_claspMaterial);
	if (itemData.factory_transparent == 'true'
			|| itemData.factory_transparent == true) {
		$('#transparent').prop("checked", true);
	}
	$('#RRP').val(itemData.factory_RRP);
	$('#accessories').val(itemData.factory_accessories);
	$('#productionNo').val(itemData.factory_productionNo);
}

// update the data from page
function doFactoryEntry() {

	var itemId = $('#itemId').val();// Token ID
	var brand = $('#brand').val();// Brand
	var modelName = $('#modelName').val();// Model Name
	var modelCode = $('#modelCode').val();// Model Code
	var movement = $('#movement').val();// Movement Serial Number
	var jewls = $('#jewls').val();// Jewelry Amount
	var material = $('#material').val();// Case Material
	var treatement = $('#treatement').val();// Case Treatement
	var glass = $('#glass').val();// Glass Material
	var bezel = $('#bezel').val();// Bezel Material
	var dial = $('#dial').val();// Dial Material
	var index = $('#index').val();// Digital Indicator

	var functions = new Array();// Function
	$("#functions-checkbox input").each(function() {
		if ($(this).prop('checked')) {
			functions.push($(this).val());
		}
	})

	var greatFunction = $("input[name='great-function']:checked").val();// Complex
	// Function
	var dimension = $('#dimension').val();// Dimension
	var strap = $('#strap').find("option:selected").val();// Strap
	var strapSize = $('#strapSize').val();// Strap Size
	var gem = $('#gem').prop('checked');// Gem Set
	var produce = $('#produce').val();// Production Year
	var gender = $("input[name='gender']:checked").val();// Suitable Gender
	var water = $('#water').prop('checked');// Water Resistance
	var claspType = $('#claspType').val();// Clasp Type
	var claspMaterial = $('#claspMaterial').val();// Clasp Material
	var transparent = $('#transparent').prop('checked');// Back Transparent
	var RRP = $('#RRP').val();// R.R.P
	var accessories = $('#accessories').val();// Accessories
	var productionNo = $('#productionNo').val();// Production No.

	var theDate = new Date();//update time
	var role = sessionStorage.getItem("role");// user's role
	var userName = sessionStorage.getItem("userName");//userName
	var userId = sessionStorage.getItem("userId");//userId
	var version = $('#data-version').html();//version
	var original_data = JSON.parse(Decrypt($('#data-code').html()));//original data

	var factoryData = {
		userId : userId,
		userName : userName,
		theDate : theDate,
		role : role,
		factory_brand : brand,
		factory_modelName : modelName,
		factory_modelCode : modelCode,
		factory_movement : movement,
		factory_jewls : jewls,
		factory_material : material,
		factory_treatement : treatement,
		factory_glass : glass,
		factory_bezel : bezel,
		factory_dial : dial,
		factory_index : index,
		factory_functions : functions,
		factory_greatFunction : greatFunction,
		factory_dimension : dimension,
		factory_strap : strap,
		factory_strapSize : strapSize,
		factory_gem : gem,
		factory_produce : produce,
		factory_gender : gender,
		factory_water : water,
		factory_claspType : claspType,
		factory_claspMaterial : claspMaterial,
		factory_transparent : transparent,
		factory_RRP : RRP,
		factory_accessories : accessories,
		factory_productionNo : productionNo
	}
	var postUrl = "/dataUpdate/updateOne";
	$
			.ajax({
				type : 'post',
				url : postUrl,
				dataType : 'json',
				data : {
					id : itemId,
					data : Encrypt(JSON.stringify($.extend(original_data,
							factoryData))),
					version : version
				},
				success : function(data) {
					if (data.result == 1) {
						alert("sucess");
					} else {
						alert("error data");
					}
				}
			})

	//console.log($.extend(data, factoryData));
}