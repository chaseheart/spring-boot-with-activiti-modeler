/**
 * 
 */

$(function() {
	$("#userId").val(sessionStorage.getItem("userId"));
	$('#userId').attr("disabled", true);
	$("#userName").val(sessionStorage.getItem("userName"));
	$('#userName').attr("disabled", true);
	$("#userAddress").val();
	$('#userAddress').attr("disabled", true);

	// searchGoods();
})

function searchGoods() {
	var postUrl = "/mobile_goodsList/searchGoods";
	$.ajax({
		type : 'post',
		url : postUrl,
		dataType : 'json',
		data : {
			id : $("#userId").val()
		},
		success : function(data) {
			if (data.result == 1) {
				$('#goodsList-data tr').remove();
				var itemList = "";
				for (var i = 0; i < data.details.length; i++) {
					var item = data.details[i]
					itemList += '<tr id="' + item[i].id + '">';
					itemList += '<td>' + (i + 1) + '</td>';
					itemList += '<td>' + item[i].id + '</td>';
					itemList += '</tr>'
				}
				$('#goodsList-data').append(itemList);

				$('#goodsList-data tr').bind('click', function() {
					window.location.href = "/history?id=" + $(this).attr('id');
				})
			} else {
				alert("no data");
			}
		}
	})
	
}
