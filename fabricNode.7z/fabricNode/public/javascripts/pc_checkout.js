//search and show result
function showUnconfirmItem(){
 var postUrl = "";
 
 $.ajax({
		type : 'post',
		url : postUrl,
		dataType : 'json',
		data:{
            flag:"1",
            id:$(".input-group input").val()
		},
		success : function(data) {
			if (data.result == 1) {
				$('.item-tbody tr').remove();
				var itemList = "";
				// made result table
				for (var i = 0; i < data.details.length; i++) {
					var item = data.details[i]
					var itemData = JSON.parse(Decrypt(item.data));
					itemList += '<tr id="' + item.id + '">';
					itemList += '<td>' + (i + 1) + '</td>';
					itemList += '<td>' + itemData.updateDate + '</td>';
					itemList += '<td>' + itemData.initiator + '</td>';
					itemList += '<td><a href="/infoHistory?id='+ itemData.tokenID +'">' + itemData.tokenID + '</a></td>';
					itemList += '<td>' + "" + '</td>';
					itemList += '<td>待确认</td>';
					itemList += '<td><span style="display:none;">' + itemData.version + '</span>';
					itemList += '<div class="btn-group"><button class="btn btn-primary lang-change" id="checkout-html-confirm">同意</button>';
					itemList +='<button class="btn btn-warning lang-change" id="checkout-html-veto">否决</button></div></td></tr>';
				}
				$('.item-tbody').append(itemList);
				var lang = sessionStorage.getItem("lang")
				if (lang != 'zh_CN') {
					lang = 'en_US'
				}
				loadProperties(lang);
				madePageCount(1, 15);
			}
			
		}
	})
	
}

// to make page turn
function madePageCount(pno, psize){
        $("#pageCount").empty();
        var itable = $(".item-tbody")[0];
        var num = itable.rows.length;
        var totalPage = 0;
        var pageSize = psize;
        if (num/pageSize > parseInt(num / pageSize)) {
                totalPage = parseInt(num / pageSize) + 1;
        } else {
                totalPage = parseInt(num / pageSize);
        }
    var currentPage = pno;

    var startRow = (currentPage - 1) * pageSize + 1;
    var endRow = currentPage * pageSize;
    endRow = (endRow > num) ? num : endRow;

    for (var i = 1; i < (num + 1); i++) {
            var irow = itable.rows[i - 1];
            if (i >= startRow && i <= endRow) {
                    irow.style.display = "table-row";
            } else {
                    irow.style.display = "none";
            }
    }
    var pageStr = '<ul class="pagination">';
    pageStr += '<li id="previousPage"><a href="#">&laquo;</a></li>';
    pageStr += '<li class="active"><a href="#" onclick="goPage(' + 1 + ','
                    + psize + ')">1</a></li>';

    for (var i = 1; i < totalPage; i++) {
            pageStr += '<li><a href="#" onclick="goPage(' + (i + 1) + ',' + psize
                            + ')">' + (i + 1) + '</a></li>';
    }

    pageStr += '<li id="nextPage"><a href="#">&raquo;</a></li>';

    $("#pageCount").append(pageStr);

    $("#previousPage").click(function() {
        if ($(".pagination").children(".active").index() == 1) {
                return false;
        }
        $(".pagination").children(".active").prev().children("a").click();
        $(".pagination").children(".active").click();
    })
    $("#nextPage").click(function() {
        if ($(".pagination").children(".active")
                .index() + 1 == $(".pagination")
                .children("li").length - 1) {
                     return false;
        }
        $(".pagination").children(".active").next().children("a").click();
        $(".pagination").children(".active").click();
    })
}

// to jump page
function goPage(pno, psize) {
		var itable = $(".item-tbody")[0];
        var num = itable.rows.length;
        var totalPage = 0;
        var pageSize = psize;
        if (num / pageSize > parseInt(num / pageSize)) {
                totalPage = parseInt(num / pageSize) + 1;
        } else {
                totalPage = parseInt(num / pageSize);
        }
    var currentPage = pno;

    var startRow = (currentPage - 1) * pageSize + 1;
    var endRow = currentPage * pageSize;
    endRow = (endRow > num) ? num : endRow;

    for (var i = 1; i < (num + 1); i++) {
            var irow = itable.rows[i - 1];
            if (i >= startRow && i <= endRow) {
                    irow.style.display = "table-row";
            } else {
                    irow.style.display = "none";
            }
    }
    $(".pagination").children("li").click(function() {
                            if (this.id != "previousPage" && this.id != "nextPage") {
                                    $(".pagination").children("li").removeClass("active");
                                    $(this).addClass("active");
                            }
                    })
}