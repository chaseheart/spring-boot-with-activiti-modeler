/**
 * 
 */

//check user's platform to hide or show nav
$(function() {
	if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|OperaMini/i
			.test(navigator.userAgent)) {
		$("#nav").remove();
	} else {
		$(".breadcrumb").remove();
	}
	
	$('#check-button button').bind('click',function(){
		doCheck();
	})
})
//check the item ID for next step
function doCheck(){
	var id = $("#itemId").val();
	var postUrl = "/checkId/doCheck"
		$.ajax({
			type : 'post',
			url : postUrl,
			data : {id:id},
			dataType : 'json',
			success : function(data) {
				if (data.result == '1') {
					window.location.href = "/"+data.aim+"?id="+data.id;
				}
			}
		})
}