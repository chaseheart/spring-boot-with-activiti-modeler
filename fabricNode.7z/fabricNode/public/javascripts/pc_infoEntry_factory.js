/**
 * 
 */
$(function() {

	$("#pcInfoEntryFactory-html-entry").bind('click', function() {

		doFactoryEntry();
	})

})

function doFactoryEntry() {

	var itemId = $('#itemId').val();// Token ID
	var brand = $('#brand').val();// Brand
	var modelName = $('#modelName').val();// Model Name
	var modelCode = $('#modelCode').val();// Model Code
	var movement = $('#movement').val();// Movement Serial Number
	var jewls = $('#jewls').val();// Jewelry Amount
	var material = $('#material').val();// Case Material
	var treatement = $('#treatement').val();// Case Treatement
	var glass = $('#glass').val();// Glass Material
	var bezel = $('#bezel').val();// Bezel Material
	var dial = $('#dial').val();// Dial Material
	var index = $('#index').val();// Digital Indicator

	var functions = new Array();// Function
	$("#functions-checkbox input").each(function() {
		if ($(this).prop('checked')) {
			functions.push($(this).val());
		}
	})

	var greatFunction = $("input[name='great-function']:checked").val();// Complex
																		// Function
	var dimension = $('#dimension').val();// Dimension
	var strap = $('#strap').find("option:selected").val();// Strap
	var strapSize = $('#strapSize').val();// Strap Size
	var gem = $('#gem').prop('checked');// Gem Set
	var produce = $('#produce').val();// Production Year
	var gender = $("input[name='gender']:checked").val();// Suitable Gender
	var water = $('#water').prop('checked');// Water Resistance
	var claspType = $('#claspType').val();// Clasp Type
	var claspMaterial = $('#claspMaterial').val();// Clasp Material
	var transparent = $('#transparent').prop('checked');// Back Transparent
	var RRP = $('#RRP').val();// R.R.P
	var accessories = $('#accessories').val();// Accessories
	var productionNo = $('#productionNo').val();// Production No.

	var theDate = new Date();
	var role = sessionStorage.getItem("role");
	var userName = sessionStorage.getItem("userName");
	var userId = sessionStorage.getItem("userId");

	var factoryData = {
		userId : userId,
		userName : userName,
		theDate : theDate,
		role : role,
		itemId : itemId,
		factory_brand : brand,
		factory_modelName : modelName,
		factory_modelCode : modelCode,
		factory_movement : movement,
		factory_jewls : jewls,
		factory_material : material,
		factory_treatement : treatement,
		factory_glass : glass,
		factory_bezel : bezel,
		factory_dial : dial,
		factory_index : index,
		factory_functions : functions,
		factory_greatFunction : greatFunction,
		factory_dimension : dimension,
		factory_strap : strap,
		factory_strapSize : strapSize,
		factory_gem : gem,
		factory_produce : produce,
		factory_gender : gender,
		factory_water : water,
		factory_claspType : claspType,
		factory_claspMaterial : claspMaterial,
		factory_transparent : transparent,
		factory_RRP : RRP,
		factory_accessories : accessories,
		factory_productionNo : productionNo
	}

	var postUrl = "/pc_infoEntry_factory/saveNewItem";
	$.ajax({
		type : 'post',
		url : postUrl,
		dataType : 'json',
		data : {
			id : itemId,
			data : Encrypt(JSON.stringify(factoryData))
		},
		success : function(data) {
			if (data.result == 1) {
				alert("sucess");
			}else {
				alert("error data");
			}
		}
	})
	//console.log(factoryData);
}