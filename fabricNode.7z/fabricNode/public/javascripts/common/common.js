/**
 * language change common function
 * @returns
 */
$(function(){
	var lang = sessionStorage.getItem("lang")
	if(lang != 'zh_CN'){lang='en_US'}
	loadProperties(lang);
})

function loadProperties(type) {
	jQuery.i18n.properties({
		name : 'strings', // 资源文件名称
		path : 'language_config/', // 资源文件所在目录路径
		mode : 'map', // 模式：变量或 Map
		language : type, // 对应的语言
		cache : false,
		encoding : 'UTF-8',
		callback : function() { // 回调方法
			$('.lang-change').each(function(){
				var id = $(this).attr('id')
				if(id.split('-')[1]=='html'){
					$(this).html($.i18n.prop('string_'+id))
				}
				else{
					$(this).attr(id.split('-')[1],$.i18n.prop('string_'+id))
				}
				
			})
		}
	});
}