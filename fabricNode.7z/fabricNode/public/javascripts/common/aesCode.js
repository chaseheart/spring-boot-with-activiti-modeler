/**
 *加密解密方法
 */
var publicKey = "qwer1234"

//加密
function Encrypt(word){
	var key = CryptoJS.enc.Utf8.parse(publicKey);
	var srcs = CryptoJS.enc.Utf8.parse(word);
	var encrypted = CryptoJS.AES.encrypt(srcs, key, {mode:CryptoJS.mode.ECB,padding:CryptoJS.pad.Pkcs7});
	return encrypted.toString();
}
//解密
function Decrypt(word){
	var key = CryptoJS.enc.Utf8.parse(publicKey);
	var decrypted = CryptoJS.AES.decrypt(word, key, {mode:CryptoJS.mode.ECB,padding:CryptoJS.pad.Pkcs7});
	return CryptoJS.enc.Utf8.stringify(decrypted).toString();
}