var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var ejs = require("ejs");
var session = require('express-session')
var csv = require('node-csv');
// csv path
var filePath = "./public/user.csv"

var commonRouter = require('./routes/common_routes');
var loginRouter = require('./routes/login_routes');
var mobileMainRouter = require('./routes/mobile_main_routes')
var pcMainRouter = require('./routes/pc_main_routes')
var pcInfoEntryFactoryRouter = require('./routes/pc_infoEntryFactory_routes')
var pcInfoUpdateFactoryRouter = require('./routes/pc_infoUpdateFactory_routes')
var pcInfoEntryTradingRouter = require('./routes/pc_infoEntryTrading_routes')
var pcInfoUpdateTradingRouter = require('./routes/pc_infoUpdateTrading_routes')
var pcMaintenanceRouter = require('./routes/pc_maintenance_routes')
var pcTransactionRouter = require('./routes/pc_transaction_routes')
var pcCheckoutRouter = require('./routes/pc_checkout_routes')
var historyRouter = require('./routes/history_routes')
var mobileGoodsListRouter = require('./routes/mobile_goodsList_routes')
var checkIdRouter = require('./routes/checkId_routes')
var infoHistoryRouter = require('./routes/infoHistory_routes')
var dataSearchRouter = require('./routes/data_search_routes')
var dataUpdateRouter = require('./routes/data_update_routes')

var pcTransport = require('./routes/pc_transport_routes')
var pcCustoms = require('./routes/pc_customs_routes')
var pcInsurance = require('./routes/pc_insurance_routes')

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.engine("html",ejs.__express)
app.set('view engine', 'html');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cookieParser());
app.use(session({
	secret:'nodejs',
	cookie:{maxAge:1000*60*30*5},
	resave:false,
	saveUninitialized:false
}));

app.use('/', commonRouter);
app.use('/login', loginRouter);
app.use('/mobile_main',mobileMainRouter)
app.use('/pc_main',pcMainRouter)
app.use('/pc_infoEntry_factory',pcInfoEntryFactoryRouter)
app.use('/pc_infoUpdate_factory',pcInfoUpdateFactoryRouter)
app.use('/pc_infoEntry_trading',pcInfoEntryTradingRouter)
app.use('/pc_infoUpdate_trading',pcInfoUpdateTradingRouter)
app.use('/pc_maintenance',pcMaintenanceRouter)
app.use('/pc_transaction',pcTransactionRouter)
app.use('/pc_checkout',pcCheckoutRouter)
app.use('/history',historyRouter)
app.use('/mobile_goodsList',mobileGoodsListRouter)
app.use('/checkId',checkIdRouter)
app.use('/infoHistory',infoHistoryRouter)
app.use('/dataSearch',dataSearchRouter)
app.use('/dataUpdate',dataUpdateRouter)

app.use('/pc_transport',pcTransport)
app.use('/pc_customs',pcCustoms)
app.use('/pc_insurance',pcInsurance)


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  console.error("   **err status: "+err.message);
  res.status(err.status || 500);
  res.render('error');
});

// csv read users'login info
csv.createParser().parseFile(filePath, function(err, data) {
	if (err) {
		return err;
	}
	var userJson=[];
	for(var i in data){
		var userData = {
			"_id":data[i][0],
			"userName":data[i][1],
			"password":data[i][2],
			"role":data[i][3]
		}
		userJson.push(userData);
	}
	
	global.users = userJson;
	
	console.log("****global_users:"+JSON.stringify(global.users))
})

module.exports = app;
