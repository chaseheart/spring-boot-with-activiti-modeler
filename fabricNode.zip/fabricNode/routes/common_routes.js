/**
 * 
 */
var express = require('express');
var router = express.Router();
var session = require('express-session')

/* GET home page. */
router.get('/', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.sendfile("./views/login.html");
});
router.get('/language_config/index', function(req, res, next) {
	res.json({result:1});
	  });
router.get('/language_config/strings_en_US.properties', function(req, res, next) {
	res.json({result:1});
	  });
router.get('/language_config/strings_en.properties', function(req, res, next) {
	res.json({result:1});
	  });
router.get('/language_config/strings.properties', function(req, res, next) {
	res.json({result:1});
	  });
router.get('/language_config/strings_zh.properties', function(req, res, next) {
	res.json({result:1});
	  });

//拦截器
router.get('/*',function(req, res, next){
	
	var jsPattern = /\.js$/;
	var url=req.url;
	console.error("res url: "+url);
	if(jsPattern.test(url)){
		next();
		return;
	}
	if(url=='/login'||url=='/error'){
		next();
		return;
	}
	if(req.session.user!=undefined||req.session.userId==0){
		next();
	}
	else{
		res.redirect('login');
	}
});

module.exports = router;