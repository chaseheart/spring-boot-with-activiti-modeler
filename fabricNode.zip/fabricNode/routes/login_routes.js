var express = require('express');
var router = express.Router();
var session = require('express-session')
/* GET home page. */
router.get('/', function(req, res, next) {
	res.render('login');
});

/**
 * user login
 * @param req
 * @param res
 * @param next
 * @returns
 */
router.post('/userLogin', function(req, res, next) {
	
	var user={
			userName:req.body.userName,
			password:req.body.password
	}
	var result = getItem(global.users,user);
	if(result!=undefined){
		req.session.user=result;
		res.json({result:1,user:result});
	}
	else{
		res.json({result:0});
	}
});

/**
 * 在json数组arr中检索obj
 * @param arr
 * @param obj
 * @returns
 */
function getItem(arr,obj){
	arrFor:for(var i = 0;i<arr.length; i++){
		for(var n in obj){
			console.log(n);
			if(arr[i][n]!=obj[n]){
				continue arrFor;
			}
		}
		return arr[i];
	}
}

module.exports = router;
