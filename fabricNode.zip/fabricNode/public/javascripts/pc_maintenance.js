/**
 * 
 */

$(function() {
	// doSearch()
	$("#pcMaintenance-html-submit").bind('click', function() {

		infoSubmit();
	})
})

function doSearch() {
	var postUrl = "/dataSearch/searchOne";
	$.ajax({
		type : 'get',
		url : postUrl,
		dataType : 'json',
		success : function(data) {
			if (data.result == 1) {
				$('#itemId').val(data.details.id);
				$('#itemId').attr("disabled", true);
				$('#data-version').html(data.details.version);
				$('#data-code').html(data.details.data)
				itemData = JSON.parse(Decrypt(data.details.data));
				showData(itemData);
			} else {
				alert("no data");
			}
		}
	})
}

// submit form information
function infoSubmit() {
	var itemId = $("#itemId").val();// Customer ID
	var customerId = $("#customerId").val();// Customer Name
	var customer = $("#customer").val();// Maintenance Date
	var maintenanceDate = $("#maintenanceDate").val();// Remark
	var remarks = $("#remarks").val();

	var theDate = new Date();// update time
	var role = sessionStorage.getItem("role");// user's role
	var userName = sessionStorage.getItem("userName");// userName
	var userId = sessionStorage.getItem("userId");// userId
	var version = $('#data-version').html();// version
	var original_data = JSON.parse(Decrypt($('#data-code').html()));// original data

	var maintenanceData = {
		userId : userId,
		userName : userName,
		theDate : theDate,
		role : role,
		maintenance_customerId : customerId,
		maintenance_customer : customer,
		maintenance_maintenanceDate : maintenanceDate,
		maintenance_remarks : remarks
	};
	
	var postUrl = "/dataUpdate/updateOne";
	$
			.ajax({
				type : 'post',
				url : postUrl,
				dataType : 'json',
				data : {
					id : itemId,
					data : Encrypt(JSON.stringify($.extend(original_data,
							factoryData))),
					version : version
				},
				success : function(data) {
					if (data.result == 1) {
						alert("sucess");
					} else {
						alert("error data");
					}
				}
			})
}