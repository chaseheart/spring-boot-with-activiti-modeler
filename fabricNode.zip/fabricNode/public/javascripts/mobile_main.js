/**
 * 
 */
$(function() {
	$("#mobileMain-html-historySearch").bind("click", function() {
		window.location.href = "/checkId?aim=history";
	});
	$("#mobileMain-html-itemList").bind("click", function() {
		window.location.href = "/mobile_goodsList";
	});
	switchLanguage();
})

// to switch language
function switchLanguage() {
	$("#Chinese").click(function() {
		sessionStorage.setItem("lang", "zh_CN");
		var lang = "zh_CN";
		loadProperties(lang);
		$("#menu-bar-button").click();
	})
	$("#English").click(function() {
		sessionStorage.setItem("lang", "en_US");
		var lang = "en_US";
		loadProperties(lang);
		$("#menu-bar-button").click();
	})
}

// logout
function logout() {
	var postUrl = "pc_main/logout";
	$.ajax({
		type : 'get',
		url : postUrl,
		dataType : 'json',
	});
	window.location.href = "/login";
}