/**
 * 
 */
$(function() {
	// doSearch()
	$("#pcTransaction-html-submit").bind('click', function() {

		doFactoryEntry();
	})
})

// get item data from fabric
function doSearch() {
	var postUrl = "/dataSearch/searchOne";
	$.ajax({
		type : 'get',
		url : postUrl,
		dataType : 'json',
		success : function(data) {
			if (data.result == 1) {
				$('#itemId').val(data.details.id);
				$('#itemId').attr("disabled", true);
				$('#data-version').html(data.details.version);
				$('#data-code').html(data.details.data)
				itemData = JSON.parse(Decrypt(data.details.data));
				showData(itemData);
			} else {
				alert("no data");
			}
		}
	})
}

// submit form information
function infoSubmit() {
	var itemId = $("#itemId").val();// Token ID
	var employeeId = $("#employeeId").val();// Employee ID
	var transactionDate = $("#transactionDate").val();// Transaction Date
	var transactionPrice = $("#transactionPrice").val();// Transaction Price
	var customerIdSeller = $("#customerIdSeller").val();// Customer ID(Seller)
	var customerSeller = $("#customerSeller").val();// Customer Name(Seller)
	var customerIdBuyer = $("#customerIdBuyer").val();// Customer ID(Buyer)
	var customerBuyer = $("#customerBuyer").val();// Customer Name(Buyer)
	var remarks = $("#remarks").val();// Remark

	var theDate = new Date();// update time
	var role = sessionStorage.getItem("role");// user's role
	var userName = sessionStorage.getItem("userName");// userName
	var userId = sessionStorage.getItem("userId");// userId
	var version = $('#data-version').html();// version
	var original_data = JSON.parse(Decrypt($('#data-code').html()));// original data

	var transactionData = {
		userId : userId,
		userName : userName,
		theDate : theDate,
		role : role,
		transaction_employeeId : employeeId,
		transaction_transactionDate : transactionDate,
		transaction_transactionPrice : transactionPrice,
		transaction_customerIdSeller : customerIdSeller,
		transaction_customerSeller : customerSeller,
		transaction_customerIdBuyer : customerIdBuyer,
		transaction_customerBuyer : customerBuyer,
		transaction_remarks : remarks
	};
	
	var postUrl = "/dataUpdate/updateOne";
	$
			.ajax({
				type : 'post',
				url : postUrl,
				dataType : 'json',
				data : {
					id : itemId,
					data : Encrypt(JSON.stringify($.extend(original_data,
							factoryData))),
					version : version
				},
				success : function(data) {
					if (data.result == 1) {
						alert("sucess");
					} else {
						alert("error data");
					}
				}
			})
}