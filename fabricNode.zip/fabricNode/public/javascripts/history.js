/**
 * 
 */

// check user's platform to hide or show nav
$(function() {
	if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|OperaMini/i
			.test(navigator.userAgent)) {
		$("#nav").remove();
	} else {
		$(".breadcrumb").remove();
	}

	//doSearch();
})
// search history and list those what had changed
function doSearch() {
	//check language
	var lang = sessionStorage.getItem("lang")
	var string_add = " ";
	var string_to = " ";
	var string_change = " ";
	var string_from = " ";
	var string_nothing = " ";
	
	if (lang != 'zh_CN') {
		string_add = " add ";
		string_to = " to ";
		string_change = " change ";
		string_from = " from ";
		string_nothing = "nothing changed";
	} else {
		string_add = " 添加 ";
		string_to = " 为 ";
		string_change = " 修改 ";
		string_from = " 从 ";
		string_nothing = "没有变动";
	}

	//require for history data
	$("#logistics-data div").remove();
	var postUrl = "/page3_PC/showLogistics";
	$
			.ajax({
				type : 'get',
				url : postUrl,
				dataType : 'json',
				success : function(data) {
					if (data.result == 1) {

						var msg = data.details;

						var firstMsgDetails = "";
						var msgCount2 = 1;
						var jsonData = JSON
								.parse(Decrypt(JSON.parse(msg[0]).data));
						// compara the first with the second record
						for ( var key in jsonData) {
							if (key == "theDate" || key == "role"
									|| key == "userName") {
								continue;
							}
							if (msgCount2 == 3) {
								msgDetails += "<br> ...";
								break;
							}
							firstMsgDetails += "<br>" + jsonData.userName
									+ string_add + key + string_to + jsonData[key];
							msgCount++;
						}

						var data0 = "<div class=\"row\">";
						data0 += "<p style=\"display: none\">"
								+ JSON.parse(msg[0]).data + "</p>"
						data0 += "<div class=\"col-xs-3\"><span  class=\"glyphicon glyphicon-map-marker\"></span></div>";
						data0 += "<div class=\"col-xs-9\">" + jsonData.theDate
								+ firstMsgDetails + "</div></div>"
						$("#logistics-data").append(data0);
						// compara the others record
						for (var i = 1; i < msg.length; i++) {
							var jsonData1 = JSON.parse(Decrypt(JSON
									.parse(msg[i]).data));
							var jsonData2 = JSON.parse(Decrypt(JSON
									.parse(msg[i - 1]).data));

							var msgDetails = "";
							var msgCount = 1;
							for ( var key in jsonData1) {
								if (msgCount == 3) {
									msgDetails += "<br> ...";
									break;
								}
								if (key == "theDate" || key == "role"
										|| key == "userName") {
									continue;
								}
								if (jsonData2[key] == undefined) {
									msgDetails += "<br>" + jsonData1.userName
											+ string_add + key + string_to
											+ jsonData1[key];
									msgCount++;
								} else if (jsonData2[key] != jsonData1[key]) {
									msgDetails += "<br>" + jsonData1.userName
											+ string_change + key + string_from
											+ jsonData2[key] + string_to
											+ jsonData1[key];
									msgCount++;
								}

							}
							if (msgDetails == "") {
								msgDetails += "<br>"+string_nothing;
							}
							var dataList = "<div class=\"row\">";
							dataList += "<p style=\"display: none\">"
									+ JSON.parse(msg[i]).data + "</p>"
							if (i == (msg.length - 1)) {
								dataList += "<div class=\"col-xs-3\"><span  class=\"glyphicon glyphicon-map-marker\"></span><br><span class=\"lead-line\"></span></div>";
							} else {
								dataList += "<div class=\"col-xs-3\"><span  class=\"glyphicon glyphicon-map-marker\"></span></div>";
							}
							dataList += "<div class=\"col-xs-9\">"
									+ jsonData1.theDate + msgDetails
									+ "</div></div>"
							$("#logistics-data").append(dataList)
						}

//						$(".row").bind(
//								"click",
//								function() {
//									itemData = JSON.parse(Decrypt($(this).find(
//											"p").html()));
//									$("#Name").html(itemData.itemName);
//									$("#Price").html(itemData.itemPrice);
//									$("#Role").html(itemData.role);
//									$("#User").html(itemData.userName);
//									$("#Time").html(itemData.theDate);
//								})
					}
				}
			})
}