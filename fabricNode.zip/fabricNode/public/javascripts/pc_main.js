/**
 * 
 */

// menu act
$(function() {

	var role = sessionStorage.getItem("role");

	$(".container-fluid p").html(sessionStorage.getItem("userName"))
	// only for factory role
	if (role == 'c1') {
		$("#pcMain-html-menu1link1").attr("href", '/pc_infoEntry_factory');
		$("#pcMain-html-menu1link2").attr("href",
				'/checkId?aim=pc_infoUpdate_factory');
		$(".role3-only,.role4-only").remove();
	}
	// only for trading role
	else if (role == 'c2' || role == 'c3') {
		$("#pcMain-html-menu1link1").attr("href", '/pc_infoEntry_trading');
		$("#pcMain-html-menu1link2").attr("href",
				'/checkId?aim=pc_infoUpdate_trading');
	}
	// only for transport role
	else if (role == 'c5') {
		$("#hear1").css("display", "none");
		$("#sub1").css("display", "none");
		$("#hear2").css("display", "block");
		$("#sub2").css("display", "block");

		$(".role5-only").css("display", "block");
	}
	// only for customs role
	else if (role == 'c6') {
		$("#hear1").css("display", "none");
		$("#sub1").css("display", "none");
		$("#hear2").css("display", "block");
		$("#sub2").css("display", "block");

		$(".role6-only").css("display", "block");
	}
	// only for insurance role
	else if (role == 'c7') {
		$("#hear1").css("display", "none");
		$("#sub1").css("display", "none");
		$("#hear2").css("display", "block");
		$("#sub2").css("display", "block");

		$(".role7-only").css("display", "block");
	}

	// the consensus number that user should deal with
	$("#pcMain-html-menu1link3").append(
			"<span class='message_number'>99+</span>")
	// auto change the width of iframe
	$("#page-data").css("width",
			"calc(100% - " + $("#panelContainer").css("width") + ")");
	$(".panel-group .panel").css("width", $("#panelContainer").css("width"));

	// menu click action
	$(".panel-heading").on(
			"click",
			function(e) {
				var idLength = e.currentTarget.id.length;
				var index = e.currentTarget.id.substr(idLength - 1, idLength);
				$("#sub" + index).on(
						'hidden.bs.collapse',
						function() {
							$(e.currentTarget).find("span").removeClass(
									"glyphicon glyphicon-triangle-bottom");
							$(e.currentTarget).find("span").addClass(
									"glyphicon glyphicon-triangle-right");
						})
				$("#sub" + index).on(
						'shown.bs.collapse',
						function() {
							$(e.currentTarget).find("span").removeClass(
									"glyphicon glyphicon-triangle-right");
							$(e.currentTarget).find("span").addClass(
									"glyphicon glyphicon-triangle-bottom");
						})
			})
	$(".width-bar-menu").bind("click", function() {
		animateEvent();
	});

	// language switch button
	var lang = sessionStorage.getItem("lang")
	if (lang != 'zh_CN') {
		lang = 'en_US'
		$(".language-button").children("#English").addClass("active");
		$(".language-button").children("#English").css("font-weight", "600");
	} else {
		$(".language-button").children("#Chinese").addClass("active");
		$(".language-button").children("#Chinese").css("font-weight", "600");
	}
	switchLanguage();

	// search message number
	/*setInterval(getMessage, 5000);*/
})

// search message number
function getMessage() {
	var postUrlPage2 = "/page2_PC/getRichCheck"
	$.ajax({
		type : 'POST',
		url : postUrlPage2,
		success : function(data) {
			if (data.result == 1) {
				var result = data.details.result;
				var unconfirm = new Array();
				for (var i = 0; i < result.length; i++) {
					var item = JSON.parse(Decrypt(result[i].data));
					if (item.role != data.user.role) {
						unconfirm.push(result[i]);
					}
				}
				if (unconfirm.length != 0 && unconfirm.length <= 99) {
					$(".message_number").text(unconfirm.length);
					$(".message_number").css("display", "inline-block");
					$("#pcMain-html-menu1link3").children(".message_number")
							.text(unconfirm.length);
					$("#pcMain-html-menu1link3").children(".message_number")
							.css("display", "inline-block");
				} else if (unconfirm.length > 99) {
					$(".message_number").text("99+");
					$(".message_number").css("display", "inline-block");
					$("#pcMain-html-menu1link3").children(".message_number")
							.text("99+");
					$("#pcMain-html-menu1link3").children(".message_number")
							.css("display", "inline-block");
				}
			}
		}
	})
}

// jump to the checkout page
function openMessage() {
	$("#pcMain-html-menu1link3")[0].click();
	$(".message_number").text("0");
}

// to switch language
function switchLanguage() {
	$(".language-button").children("#Chinese").click(function() {
		sessionStorage.setItem("lang", "zh_CN");
		var lang = "zh_CN";
		loadProperties(lang);
		$(".language-button").children("button").removeClass("active");
		$(".language-button").children("button").css("font-weight", "unset");
		$(this).addClass("active");
		$(this).css("font-weight", "600");
		window.location.reload();
	})
	$(".language-button").children("#English").click(function() {
		sessionStorage.setItem("lang", "en_US");
		var lang = "en_US";
		loadProperties(lang);
		$(".language-button").children("button").removeClass("active");
		$(".language-button").children("button").css("font-weight", "unset");
		$(this).addClass("active");
		$(this).css("font-weight", "600");
		window.location.reload();
	})
}

// logout
function logout() {
	if (confirm("确认注销？")) {
		var postUrl = "pc_main/logout";
		$.ajax({
			type : 'get',
			url : postUrl,
			dataType : 'json',
		});
		window.location.href = "/login";
	}

}
// hidn menu action
function animateEvent() {
	if ($("#panelContainer").css("width") == "0px") {
		$("#panelContainer").animate({
			width : "250px"
		}, 600);
		$(".width-bar-menu").animate({
			"margin-left" : "250px",
			left : "unset"
		}, 600);
		$("#page-data").css("width", "calc(100% - 250px");
	} else {
		$("#panelContainer").animate({
			width : "0px"
		}, 400);
		$(".width-bar-menu").animate({
			"margin-left" : "0px",
			left : "0px"
		}, 400);
		$("#page-data").animate({
			width : "100%"
		}, 600);
	}

}