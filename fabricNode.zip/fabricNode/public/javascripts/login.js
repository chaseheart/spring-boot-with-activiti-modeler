/**
 * 
 */

$(function(){
	$("#login-html-login").bind("click",function(){
		loginCheck();
	})
})
// 检查填写内容
function loginCheck() {
	var userName = jQuery.trim(document.getElementById("userName").value);
	var password = jQuery.trim(document.getElementById("password").value);

	document.getElementById("userName").value = userName;
	document.getElementById("password").value = password;

	if (userName == '' || password == '') {
		
	}else {
		useLogin(userName, password);
	}

}

//登录请求
function useLogin(userName, password) {

	// alert(passwordCode);
	var postData = {
		"userName" : userName,
		"password" : password
	};
	var postUrl = "/login/userLogin";
	$.ajax({
		type : 'post',
		url : postUrl,
		data : postData,
		dataType : 'json',
		success : function(data) {
			// console.log(data);
			if (data.result == '1') {
				sessionStorage.setItem("userId", data.user._id);
				sessionStorage.setItem("userName", data.user.userName);
				sessionStorage.setItem("role", data.user.role);
				//判断设备
				if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|OperaMini/i.test(navigator.userAgent)){
					window.location.href = "/mobile_main";
				}
				else{
					window.location.href = "/pc_main";
				}
				
			} else {
				
				//document.getElementById("msg").innerHTML = "用户名密码错误"
			}
		},
		error : function(data) {
			window.location.href = "/error";
		}

	});

}
//语言切换
function changeLang(lang){
	sessionStorage.setItem("lang",lang);
	window.location.reload();
}