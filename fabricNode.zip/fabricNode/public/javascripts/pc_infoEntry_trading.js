/**
 * 
 */
$(function() {
	// doSearch()
	
	$("#pcInfoEntryTrading-html-entry").bind('click', function() {

		infoEntry();
	})
})
// get item data from fabric
function doSearch() {
	var postUrl = "/dataSearch/searchOne";
	$.ajax({
		type : 'get',
		url : postUrl,
		dataType : 'json',
		success : function(data) {
			if (data.result == 1) {
				$('#itemId').val(data.details.id);
				$('#itemId').attr("disabled", true);
				$('#data-version').html(data.details.version);
				$('#data-code').html(data.details.data)
			} else {
				alert("no data");
			}
		}
	})
}

// entry information from form
function infoEntry() {
	var itemId = $("#itemId").val();// Token ID
	var distributorName = $("#distributorName").val();// Distributor Name
	var distributorInfor = $("#distributorInfor").val();// Distributor Info
	var employeeId = $("#employeeId").val();// Employee ID
	var receivedDate = $("#receivedDate").val();// Received Date
	var soldDate = $("#soldDate").val();// Sold Date
	var soldPrice = $("#soldPrice").val();// Sold Price
	var customerId = $("#customerId").val();// Customer ID
	var customer = $("#customer").val();// Customer Name

	var theDate = new Date();// update time
	var role = sessionStorage.getItem("role");// user's role
	var userName = sessionStorage.getItem("userName");// userName
	var userId = sessionStorage.getItem("userId");// userId
	var version = $('#data-version').html();// version
	var original_data = JSON.parse(Decrypt($('#data-code').html()));// original data

	var tradingData = {
		userId : userId,
		userName : userName,
		theDate : theDate,
		role : role,
		trading_distributorName : distributorName,
		trading_distributorInfor : distributorInfor,
		trading_employeeId : employeeId,
		trading_receivedDate : receivedDate,
		trading_soldDate : soldDate,
		trading_soldPrice : soldPrice,
		trading_customerId : customerId,
		trading_customer : customer
	};

	var postUrl = "/pc_infoUpdate_factory/updateOne";
	$
			.ajax({
				type : 'post',
				url : postUrl,
				dataType : 'json',
				data : {
					id : itemId,
					data : Encrypt(JSON.stringify($.extend(original_data,
							tradingData))),
					version : version,
					customerId:customerId
				},
				success : function(data) {
					if (data.result == 1) {
						alert("sucess");
					} else {
						alert("error data");
					}
				}
			})
}